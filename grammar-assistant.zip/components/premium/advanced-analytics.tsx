"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { BarChart3, Brain, Target } from "lucide-react"
import type { AdvancedStats } from "@/lib/premium-features"

interface AdvancedAnalyticsProps {
  stats: AdvancedStats
}

export function AdvancedAnalytics({ stats }: AdvancedAnalyticsProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  const getProgressColor = (score: number) => {
    if (score >= 80) return "bg-green-500"
    if (score >= 60) return "bg-yellow-500"
    return "bg-red-500"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Advanced Analytics
        </CardTitle>
        <CardDescription>Detailed insights into your writing</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Writing Scores */}
        <div className="grid gap-4 md:grid-cols-3">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Clarity</span>
              <span className={`text-sm font-bold ${getScoreColor(stats.clarityScore)}`}>{stats.clarityScore}/100</span>
            </div>
            <Progress value={stats.clarityScore} className="h-2" />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Formality</span>
              <span className={`text-sm font-bold ${getScoreColor(stats.formalityScore)}`}>
                {stats.formalityScore}/100
              </span>
            </div>
            <Progress value={stats.formalityScore} className="h-2" />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Engagement</span>
              <span className={`text-sm font-bold ${getScoreColor(stats.engagementScore)}`}>
                {stats.engagementScore}/100
              </span>
            </div>
            <Progress value={stats.engagementScore} className="h-2" />
          </div>
        </div>

        {/* Writing Characteristics */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-3">
            <h4 className="font-medium flex items-center gap-2">
              <Brain className="h-4 w-4" />
              Writing Analysis
            </h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Vocabulary Level</span>
                <Badge variant="outline">{stats.vocabularyLevel}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Tone</span>
                <Badge variant="outline">{stats.toneAnalysis}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Sentence Complexity</span>
                <Badge variant="outline">{stats.sentenceComplexity}/100</Badge>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-medium flex items-center gap-2">
              <Target className="h-4 w-4" />
              Recommendations
            </h4>
            <div className="space-y-2 text-sm">
              {stats.clarityScore < 70 && (
                <div className="p-2 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded">
                  <span className="text-yellow-800 dark:text-yellow-200">
                    Consider using simpler sentence structures for better clarity.
                  </span>
                </div>
              )}
              {stats.engagementScore < 60 && (
                <div className="p-2 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded">
                  <span className="text-blue-800 dark:text-blue-200">
                    Try using more active voice and varied sentence lengths.
                  </span>
                </div>
              )}
              {stats.formalityScore > 80 && stats.toneAnalysis === "Casual" && (
                <div className="p-2 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded">
                  <span className="text-purple-800 dark:text-purple-200">
                    Your writing style is quite formal for a casual tone.
                  </span>
                </div>
              )}
              {stats.clarityScore >= 80 && stats.engagementScore >= 70 && (
                <div className="p-2 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded">
                  <span className="text-green-800 dark:text-green-200">
                    Excellent! Your writing is clear and engaging.
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
