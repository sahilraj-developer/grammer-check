"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ExternalLink, Search, Shield } from "lucide-react"
import type { PlagiarismResult } from "@/lib/premium-features"

interface PlagiarismCheckerProps {
  result: PlagiarismResult
}

export function PlagiarismChecker({ result }: PlagiarismCheckerProps) {
  const getScoreColor = (percentage: number) => {
    if (percentage < 5) return "text-green-600"
    if (percentage < 15) return "text-yellow-600"
    return "text-red-600"
  }

  const getScoreBadge = (percentage: number) => {
    if (percentage < 5) {
      return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Original</Badge>
    }
    if (percentage < 15) {
      return (
        <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
          Minor Similarity
        </Badge>
      )
    }
    return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">High Similarity</Badge>
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="h-5 w-5" />
          Plagiarism Detection
        </CardTitle>
        <CardDescription>Check for content originality</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center space-y-4">
          <div className="space-y-2">
            <div className={`text-4xl font-bold ${getScoreColor(result.percentage)}`}>{result.percentage}%</div>
            <div className="text-sm text-muted-foreground">Similarity Found</div>
            {getScoreBadge(result.percentage)}
          </div>

          <Progress value={result.percentage} className="h-3" />
        </div>

        {result.sources.length > 0 && (
          <div className="space-y-4">
            <h4 className="font-medium flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Similar Sources Found
            </h4>
            <div className="space-y-3">
              {result.sources.map((source, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium text-sm">{source.title}</div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <ExternalLink className="h-3 w-3" />
                      {source.url}
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {source.similarity}% match
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
          <p className="text-sm text-blue-800 dark:text-blue-200">
            <Shield className="h-4 w-4 inline mr-1" />
            {result.percentage < 5
              ? "Great! Your content appears to be original."
              : result.percentage < 15
                ? "Minor similarities detected. Review the sources above."
                : "High similarity detected. Consider revising your content."}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
