"use client"

import type React from "react"
import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  CheckCircle,
  Copy,
  RotateCcw,
  FileText,
  Zap,
  Download,
  Upload,
  User,
  LogOut,
  Crown,
  Settings,
  Wand2,
  Search,
  BarChart3,
  AlertTriangle,
  Lightbulb,
  Sparkles,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/components/auth/auth-provider"
import { LoginDialog } from "@/components/auth/login-dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { deepSeekService, type DeepSeekResponse } from "@/lib/deepseek-service"
import {
  premiumGrammarService,
  type StyleSuggestion,
  type PlagiarismResult,
  type AdvancedStats,
} from "@/lib/premium-features"
import { StyleSuggestions } from "@/components/premium/style-suggestions"
import { PlagiarismChecker } from "@/components/premium/plagiarism-checker"
import { AdvancedAnalytics } from "@/components/premium/advanced-analytics"

export default function GrammarAssistant() {
  const [inputText, setInputText] = useState("")
  const [result, setResult] = useState<DeepSeekResponse | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [styleSuggestions, setStyleSuggestions] = useState<StyleSuggestion[]>([])
  const [plagiarismResult, setPlagiarismResult] = useState<PlagiarismResult | null>(null)
  const [advancedStats, setAdvancedStats] = useState<AdvancedStats | null>(null)
  const [showLoginDialog, setShowLoginDialog] = useState(false)
  const { toast } = useToast()
  const { user, isAuthenticated, logout, updateUsage, anonymousUsage, updateAnonymousUsage, canUseAnonymous } =
    useAuth()

  const handleCorrect = async () => {
    if (!inputText.trim()) {
      toast({
        title: "No text to correct",
        description: "Please enter some text to check for grammar errors.",
        variant: "destructive",
      })
      return
    }

    if (!isAuthenticated) {
      if (!canUseAnonymous()) {
        toast({
          title: "Usage limit reached",
          description: `You've used all ${anonymousUsage.limit} free corrections. Sign up for 30 free corrections per month!`,
          variant: "destructive",
        })
        setShowLoginDialog(true)
        return
      }
    } else if (user && user.usage.corrections >= user.usage.monthlyLimit) {
      toast({
        title: "Usage limit reached",
        description: `You've reached your monthly limit of ${user.usage.monthlyLimit} corrections. Upgrade for unlimited access.`,
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)
    try {
      const grammarResult = await deepSeekService.correctGrammar(inputText)
      setResult(grammarResult)

      const hasPremiumFeatures = user?.plan === "premium" || user?.plan === "pro"
      if (hasPremiumFeatures) {
        const premiumResult = await premiumGrammarService.advancedCorrection(inputText, user?.plan || "free")

        if (premiumResult.styleSuggestions) {
          setStyleSuggestions(premiumResult.styleSuggestions)
        }
        if (premiumResult.plagiarismResult) {
          setPlagiarismResult(premiumResult.plagiarismResult)
        }
        if (premiumResult.advancedStats) {
          setAdvancedStats(premiumResult.advancedStats)
        }
      }

      if (isAuthenticated && user) {
        updateUsage(user.usage.corrections + 1)
      } else {
        updateAnonymousUsage(anonymousUsage.corrections + 1)
      }

      toast({
        title: "Analysis complete!",
        description: `Found ${grammarResult.errors.length} issues. Powered by DeepSeek AI`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to correct grammar. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleApplyFix = (errorIndex: number) => {
    if (!result) return

    const error = result.errors[errorIndex]
    const newText = inputText.replace(error.original, error.suggestion)
    setInputText(newText)

    // Remove the applied error from results
    const newErrors = result.errors.filter((_, index) => index !== errorIndex)
    setResult({ ...result, errors: newErrors })

    toast({
      title: "Fix applied",
      description: `Replaced "${error.original}" with "${error.suggestion}"`,
    })
  }

  const handleCopy = async () => {
    if (result?.corrected) {
      await navigator.clipboard.writeText(result.corrected)
      toast({
        title: "Copied!",
        description: "Corrected text has been copied to clipboard.",
      })
    }
  }

  const handleReset = () => {
    setInputText("")
    setResult(null)
    setStyleSuggestions([])
    setPlagiarismResult(null)
    setAdvancedStats(null)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && file.type === "text/plain") {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result as string
        setInputText(content)
      }
      reader.readAsText(file)
    } else {
      toast({
        title: "Invalid file type",
        description: "Please upload a .txt file.",
        variant: "destructive",
      })
    }
  }

  const handleDownload = () => {
    if (result?.corrected) {
      const blob = new Blob([result.corrected], { type: "text/plain" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "corrected-text.txt"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }
  }

  const handleLogout = async () => {
    await logout()
    toast({
      title: "Signed out",
      description: "You've been successfully signed out.",
    })
  }

  const getPlanBadge = (plan: string) => {
    switch (plan) {
      case "premium":
        return (
          <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
            <Crown className="h-3 w-3 mr-1" />
            Premium
          </Badge>
        )
      case "pro":
        return (
          <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
            <Crown className="h-3 w-3 mr-1" />
            Pro
          </Badge>
        )
      default:
        return (
          <Badge variant="secondary">
            <Zap className="h-3 w-3 mr-1" />
            Free
          </Badge>
        )
    }
  }

  const hasPremiumFeatures = user?.plan === "premium" || user?.plan === "pro"
  const errorsByType =
    result?.errors.reduce(
      (acc, error) => {
        acc[error.type] = (acc[error.type] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    ) || {}

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="mx-auto max-w-7xl px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <FileText className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold">GrammarPro</h1>
                <p className="text-xs text-muted-foreground">AI-Powered Writing Assistant</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {isAuthenticated && user ? (
                <>
                  {getPlanBadge(user.plan)}
                  <div className="hidden sm:flex text-xs text-muted-foreground">
                    {user.usage.corrections}/{user.usage.monthlyLimit} used
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <span className="hidden sm:inline">{user.name}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <User className="h-4 w-4 mr-2" />
                        <Link href="/dashboard">Dashboard</Link>
                      </DropdownMenuItem>
                      {user.isAdmin && (
                        <DropdownMenuItem>
                          <Settings className="h-4 w-4 mr-2" />
                          <Link href="/admin">Admin Panel</Link>
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout}>
                        <LogOut className="h-4 w-4 mr-2" />
                        Sign Out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <>
                  <div className="hidden sm:flex text-xs text-muted-foreground">
                    {anonymousUsage.corrections}/{anonymousUsage.limit} free checks
                  </div>
                  <Button onClick={() => setShowLoginDialog(true)} size="sm">
                    Sign In
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 space-y-8">
        <section className="text-center space-y-4">
          <h2 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Perfect Your Writing with AI
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Advanced grammar correction powered by DeepSeek AI. Get 5 free checks, then sign up for 30 free monthly
            corrections!
          </p>
        </section>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Input Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Your Text</span>
                  <div className="flex items-center gap-2">
                    {inputText && (
                      <Badge variant="outline" className="text-xs">
                        {inputText.length} chars
                      </Badge>
                    )}
                    <input type="file" accept=".txt" onChange={handleFileUpload} className="hidden" id="file-upload" />
                    <Button variant="outline" size="sm" onClick={() => document.getElementById("file-upload")?.click()}>
                      <Upload className="h-4 w-4" />
                    </Button>
                  </div>
                </CardTitle>
                <CardDescription>
                  Enter your text to check for grammar, spelling, and style issues.
                  {hasPremiumFeatures && (
                    <span className="block mt-1 text-blue-600 dark:text-blue-400">
                      Premium features enabled: Style suggestions, plagiarism detection, and advanced analytics.
                    </span>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="She dont like playing football becaus she think it boring..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="min-h-[300px] resize-none text-base leading-relaxed"
                />
                <div className="flex gap-2">
                  <Button
                    onClick={handleCorrect}
                    disabled={isProcessing || !inputText.trim()}
                    className="flex-1"
                    size="lg"
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        Analyzing with DeepSeek AI...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-4 w-4 mr-2" />
                        {hasPremiumFeatures ? "Advanced Check" : "Check Grammar"}
                      </>
                    )}
                  </Button>
                  <Button variant="outline" size="lg" onClick={handleReset} disabled={!inputText && !result}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {result && result.errors.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-500" />
                    Issues Found ({result.errors.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {result.errors.map((error, index) => (
                    <div key={index} className="flex items-start justify-between p-3 rounded-lg border bg-muted/30">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge
                            variant={
                              error.type === "grammar"
                                ? "destructive"
                                : error.type === "spelling"
                                  ? "default"
                                  : "secondary"
                            }
                            className="text-xs"
                          >
                            {error.type}
                          </Badge>
                          <span className="text-sm font-medium">
                            "{error.original}" → "{error.suggestion}"
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">{error.explanation}</p>
                      </div>
                      <Button size="sm" variant="outline" onClick={() => handleApplyFix(index)} className="ml-2">
                        Apply
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Results Section */}
          <div className="space-y-6">
            {result && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-red-500">{errorsByType.grammar || 0}</div>
                    <div className="text-xs text-muted-foreground">Grammar</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-yellow-500">{errorsByType.spelling || 0}</div>
                    <div className="text-xs text-muted-foreground">Spelling</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-500">{errorsByType.style || 0}</div>
                    <div className="text-xs text-muted-foreground">Style</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-500">{result.readabilityScore}</div>
                    <div className="text-xs text-muted-foreground">Score</div>
                  </CardContent>
                </Card>
              </div>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Corrected Text</span>
                  {result && (
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleDownload}>
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="min-h-[300px] p-4 rounded-lg border-2 border-dashed border-muted-foreground/20 bg-muted/20">
                  {isProcessing ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center space-y-2">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto" />
                        <p className="text-sm text-muted-foreground">DeepSeek AI is analyzing your text...</p>
                      </div>
                    </div>
                  ) : result?.corrected ? (
                    <p className="whitespace-pre-wrap leading-relaxed text-base">{result.corrected}</p>
                  ) : (
                    <p className="text-muted-foreground italic text-center mt-20">
                      Your corrected text will appear here...
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {result && result.improvements.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                    Writing Improvements
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {result.improvements.map((improvement, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{improvement}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {hasPremiumFeatures && (styleSuggestions.length > 0 || plagiarismResult || advancedStats) && (
          <div className="space-y-6">
            <Separator />
            <h3 className="text-2xl font-bold text-center">Premium Features</h3>

            <div className="grid gap-6 lg:grid-cols-3">
              {styleSuggestions.length > 0 && (
                <StyleSuggestions
                  suggestions={styleSuggestions}
                  onApplySuggestion={(suggestion) => {
                    if (result) {
                      const newCorrected = result.corrected.replace(suggestion.original, suggestion.suggestion)
                      setResult({ ...result, corrected: newCorrected })
                      setStyleSuggestions((prev) => prev.filter((s) => s !== suggestion))
                    }
                  }}
                />
              )}

              {plagiarismResult && <PlagiarismChecker result={plagiarismResult} />}

              {advancedStats && <AdvancedAnalytics stats={advancedStats} />}
            </div>
          </div>
        )}

        {!hasPremiumFeatures && (
          <section className="space-y-6">
            <Separator />
            <div className="text-center">
              <h3 className="text-2xl font-bold">Unlock Premium Features</h3>
              <p className="text-muted-foreground mt-2">Get advanced writing assistance with our premium plans</p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <Card className="text-center border-blue-200 dark:border-blue-800">
                <CardContent className="p-6">
                  <div className="h-12 w-12 rounded-lg bg-blue-100 dark:bg-blue-900 flex items-center justify-center mx-auto mb-4">
                    <Wand2 className="h-6 w-6 text-blue-600" />
                  </div>
                  <h4 className="font-semibold mb-2">Style Suggestions</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Get AI-powered suggestions to improve clarity, conciseness, and engagement
                  </p>
                  <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">Premium</Badge>
                </CardContent>
              </Card>

              <Card className="text-center border-purple-200 dark:border-purple-800">
                <CardContent className="p-6">
                  <div className="h-12 w-12 rounded-lg bg-purple-100 dark:bg-purple-900 flex items-center justify-center mx-auto mb-4">
                    <Search className="h-6 w-6 text-purple-600" />
                  </div>
                  <h4 className="font-semibold mb-2">Plagiarism Detection</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Check your content against billions of web pages for originality
                  </p>
                  <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">Premium</Badge>
                </CardContent>
              </Card>

              <Card className="text-center border-green-200 dark:border-green-800">
                <CardContent className="p-6">
                  <div className="h-12 w-12 rounded-lg bg-green-100 dark:bg-green-900 flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="h-6 w-6 text-green-600" />
                  </div>
                  <h4 className="font-semibold mb-2">Advanced Analytics</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Get detailed insights into tone, formality, and writing complexity
                  </p>
                  <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">Premium</Badge>
                </CardContent>
              </Card>
            </div>

            <div className="text-center">
              <Link href="/pricing">
                <Button size="lg" className="mt-4">
                  <Crown className="h-4 w-4 mr-2" />
                  Upgrade to Premium
                </Button>
              </Link>
            </div>
          </section>
        )}
      </main>

      <footer className="border-t bg-card/50 mt-16">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              <span className="font-semibold">GrammarPro</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Professional AI-powered grammar correction and writing assistance
            </p>
            <p className="text-xs text-muted-foreground">© 2024 GrammarPro. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <LoginDialog open={showLoginDialog} onOpenChange={setShowLoginDialog} />
    </div>
  )
}
