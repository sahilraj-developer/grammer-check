export interface DeepSeekConfig {
  apiKey: string
  baseUrl: string
}

export interface DeepSeekResponse {
  corrected: string
  errors: Array<{
    type: "grammar" | "spelling" | "punctuation" | "style"
    original: string
    suggestion: string
    explanation: string
    position: { start: number; end: number }
  }>
  improvements: string[]
  readabilityScore: number
}

class DeepSeekService {
  private getApiKey(): string {
    return process.env.DEEPSEEK_API_KEY || ""
  }

  private getBaseUrl(): string {
    return process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com"
  }

  isConfigured(): boolean {
    return this.getApiKey().length > 0
  }

  async correctGrammar(text: string): Promise<DeepSeekResponse> {
    const apiKey = this.getApiKey()
    const baseUrl = this.getBaseUrl()

    if (!apiKey) {
      console.warn("DeepSeek API key not found, using mock response")
      return this.getMockResponse(text)
    }

    try {
      const response = await fetch(`${baseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "deepseek-chat",
          messages: [
            {
              role: "system",
              content: `You are an advanced grammar correction assistant, similar to Grammarly. Your task:
              - Correct grammar, spelling, punctuation, and sentence structure in the user's text
              - Keep the meaning and tone the same
              - Do not change names, numbers, or factual details
              - Improve readability and clarity where necessary
              
              Return a JSON response with:
              - corrected: the corrected version of the text
              - errors: array of errors found with type, original, suggestion, explanation, and position
              - improvements: array of improvement suggestions
              - readabilityScore: score from 0-100`,
            },
            {
              role: "user",
              content: text,
            },
          ],
          temperature: 0.1,
          max_tokens: 2000,
        }),
      })

      if (!response.ok) {
        throw new Error(`DeepSeek API error: ${response.statusText}`)
      }

      const data = await response.json()
      const content = data.choices[0]?.message?.content

      try {
        return JSON.parse(content)
      } catch {
        return this.getMockResponse(text)
      }
    } catch (error) {
      console.error("DeepSeek API error:", error)
      return this.getMockResponse(text)
    }
  }

  private getMockResponse(text: string): DeepSeekResponse {
    const errors = []
    let corrected = text

    const corrections = [
      { find: /\bdont\b/g, replace: "don't", type: "grammar", explanation: "Missing apostrophe in contraction" },
      { find: /\bcant\b/g, replace: "can't", type: "grammar", explanation: "Missing apostrophe in contraction" },
      { find: /\bwont\b/g, replace: "won't", type: "grammar", explanation: "Missing apostrophe in contraction" },
      { find: /\bbecaus\b/g, replace: "because", type: "spelling", explanation: "Spelling error" },
      { find: /\bteh\b/g, replace: "the", type: "spelling", explanation: "Spelling error" },
      {
        find: /\brecieve\b/g,
        replace: "receive",
        type: "spelling",
        explanation: "Spelling error - 'i' before 'e' except after 'c'",
      },
      { find: /\bthier\b/g, replace: "their", type: "spelling", explanation: "Spelling error" },
      {
        find: /\byour\s+welcome\b/g,
        replace: "you're welcome",
        type: "grammar",
        explanation: "Should use 'you're' (you are) instead of 'your'",
      },
      {
        find: /\bits\s+a\s+good\s+day\b/g,
        replace: "it's a good day",
        type: "grammar",
        explanation: "Should use 'it's' (it is) instead of 'its'",
      },
    ]

    corrections.forEach((correction) => {
      const matches = Array.from(text.matchAll(correction.find))
      matches.forEach((match) => {
        if (match.index !== undefined) {
          errors.push({
            type: correction.type as "grammar" | "spelling" | "punctuation" | "style",
            original: match[0],
            suggestion: correction.replace,
            explanation: correction.explanation,
            position: { start: match.index, end: match.index + match[0].length },
          })
        }
      })
      corrected = corrected.replace(correction.find, correction.replace)
    })

    const improvements = []
    if (text.split(" ").length > 20) {
      improvements.push("Consider breaking long sentences into shorter ones for better readability")
    }
    if (text.split(".").length < 3 && text.length > 100) {
      improvements.push("Add more sentence variety to improve flow")
    }
    if (!text.match(/[,;:]/)) {
      improvements.push("Consider using punctuation marks like commas to separate ideas")
    }

    return {
      corrected,
      errors,
      improvements,
      readabilityScore: Math.max(60, Math.min(95, 100 - errors.length * 5)),
    }
  }
}

export const deepSeekService = new DeepSeekService()
